endpoint = "usersestimatedb.culwpfexwity.eu-west-3.rds.amazonaws.com"
port = 3306
password = "CloudParty"
user = "admin"
